import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playerslist',
  templateUrl: './playerslist.component.html',
  styleUrls: ['./playerslist.component.css']
})
export class PlayerslistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
