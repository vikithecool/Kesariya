import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewProfileComponent } from './view-profile.component';
import { ViewProfileRoutingModule } from './view-profile-routing.module';
import { TabsModule } from 'ngx-bootstrap/tabs';

@NgModule({
  declarations: [ViewProfileComponent],
  imports: [
    CommonModule,ViewProfileRoutingModule,TabsModule.forRoot(),
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
],

})
export class ViewProfileModule { }
