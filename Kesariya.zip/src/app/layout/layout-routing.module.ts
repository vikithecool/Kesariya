import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';
const routes: Routes = [
  {
      path: '',
      component: LayoutComponent,
      children: [
          { path: '', redirectTo: 'playerslist', pathMatch: 'prefix' },
          { path: 'view-profile', loadChildren: () => import('./view-profile/view-profile.module').then(m => m.ViewProfileModule)},
          { path: 'matches', loadChildren: () => import('./matches/matches.module').then(m => m.MatchesModule)},
          { path: 'stats', loadChildren: () => import('./stats/stats.module').then(m => m.StatsModule)},
          { path: 'gallery', loadChildren: () => import('./gallery/gallery.module').then(m => m.GalleryModule)},
          { path: 'playerslist', loadChildren: () => import('./playerslist/playerslist.module').then(m => m.PlayerslistModule)},
          { path: 'team', loadChildren: () => import('./team/team.module').then(m => m.TeamModule)},
      ]
  }
];
   

@NgModule({
  imports: [RouterModule.forChild(routes),CommonModule],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
